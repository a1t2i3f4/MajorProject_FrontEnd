export class User {
    id!:number;
    name!: string;
    emailId!:string;
    password!:string;

    constructor(){}
    
    }
    

