export interface Values {
    productId?: any;
    productName?: any;
    productCategory?: any;
    productRate?: any;
    description?: any;
    rating?:any;
    imageurl?:any;
  }
  